#ifndef HOMEAUTOMATIONBOX_HPP
#define HOMEAUTOMATIONBOX_HPP

#include "Capteur/CapteurAda7021/CapteurAda7021.hpp"

class EtatSysteme;

class HomeAutomationBox {
    private:
        CapteurAda7021 * capteur7021;
        EtatSysteme  * etat_systeme;
    public:
        HomeAutomationBox(CapteurAda7021 * capteur7021,EtatSysteme * etat_systeme);
        const CapteurAda7021 * getCapteur7021() const;
        void setEtatSysteme(EtatSysteme * etat_systeme);
        bool lance_toi();
};

#endif //HOMEAUTOMATIONBOX_HPP