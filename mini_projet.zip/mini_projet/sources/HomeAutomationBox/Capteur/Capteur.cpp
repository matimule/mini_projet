#include "Capteur.hpp"
#include "Protocole/Protocole.hpp"

Capteur::Capteur(const string & nom, const string & description, Protocole * protocole)
    :nom(nom), description(description), protocole(protocole){}