#ifndef CAPTEURADA7021_HPP
#define CAPTEURADA7021_HPP

#include "../Capteur.hpp"
#include "cstdint"

class CapteurAda7021 : public Capteur {
    private:
        uint16_t adresse;
    protected:
        int fd;
    public:
        CapteurAda7021(const string & nom, const string & description, Protocole * protocole, uint16_t & adresse);
        double lis_humidite() const;
        double lis_temperature() const;
        virtual void display() const;
        ~CapteurAda7021();
};

#endif //CAPTEURADA7021_HPP