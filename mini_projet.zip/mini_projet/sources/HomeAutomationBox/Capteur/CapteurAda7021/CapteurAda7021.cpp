#include <iostream>
#include <fcntl.h>
#include <unistd.h>
#include "CapteurAda7021.hpp"

using std::cout;
using std::endl;

CapteurAda7021::CapteurAda7021(const string & nom, const string & description, Protocole * protocole, uint16_t & adresse)
    :Capteur(nom,description,protocole), adresse(adresse){
        this->fd = open("/dev/i2c-1", O_RDWR);
        this->protocole->configure_toi(this->fd, this->adresse);
    }

double CapteurAda7021::lis_humidite() const {
    //Partie Operationnelle :
    uint8_t config = 0xF5;
    uint8_t data[2] = {0, 0};
    this->protocole->ecris_registre(this->fd, config);
    sleep(1);
    this->protocole->lis_registre(this->fd, data);
    return (((float) (((uint16_t) data[0] << 8) + (uint16_t) data[1]) * 125.0f) / 65536.0f) - 6.f;
    //Partie Test/Simu :
    //return 60.00;
}

double CapteurAda7021::lis_temperature() const {
    //Partie Operationnelle :
    uint8_t config = 0xF3;
    uint8_t data[2] = {0, 0};
    this->protocole->ecris_registre(this->fd, config);
    sleep(1);
    this->protocole->lis_registre(this->fd, data);
    return (((float) (((uint16_t) data[0] << 8) + (uint16_t) data[1]) * 175.72f) / 65536.0f) - 46.85f;
    //Partie Test/Simu :
    //return 25.00;
}

void CapteurAda7021::display() const{
    cout<< this->nom << "\n"
        << this->description << "\n"
        << "Humidité : " << this->lis_humidite() << "%" << "\n"
        << "Température : " << this->lis_temperature() << endl;
}

CapteurAda7021::~CapteurAda7021(){
    close(this->fd);
}