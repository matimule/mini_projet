#include "Protocole.hpp"

Protocole::Protocole(const string & nom, const string & description_utilisation)
    :nom(nom),description_utilisation(description_utilisation){}