#ifndef PROTOCOLE_HPP
#define PROTOCOLE_HPP

#include <cstdint>
#include <string>
using std::string;

class Protocole {
    private:
        string nom;
        string description_utilisation;
    public:
        Protocole(const string & nom = "", const string & description_utilisation = "");
        virtual bool configure_toi(int fd, uint16_t &adresse) = 0;
        virtual bool ecris_registre(int fd, uint8_t &config) = 0;
        virtual bool lis_registre(int fd, uint8_t * data) = 0;
};

#endif //PROTOCOLE_HPP