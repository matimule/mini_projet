#include "ProtocoleI2C.hpp"
#include "linux/i2c-dev.h"
#include "sys/ioctl.h"
#include "unistd.h"

ProtocoleI2C::ProtocoleI2C(const string & nom, const string & description_utilisation)
    :Protocole(nom,description_utilisation){}

bool ProtocoleI2C::configure_toi(int fd, uint16_t &adresse){
    if(ioctl(fd,I2C_SLAVE,adresse) < 0) return false;
    return true;
}

bool ProtocoleI2C::ecris_registre(int fd, uint8_t &config){
    if (write(fd, &config, 1) < 0) return false;
    return true;
}

bool ProtocoleI2C::lis_registre(int fd, uint8_t * data){
    if (read(fd, (void *) data, 2) != 2) return false;
    return true;
}