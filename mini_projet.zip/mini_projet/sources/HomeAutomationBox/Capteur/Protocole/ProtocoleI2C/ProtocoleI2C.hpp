#ifndef PROTOCOLEI2C_HPP
#define PROTOCOLEI2C_HPP

#include <fstream>
#include "../Protocole.hpp"

using std::ifstream;

class ProtocoleI2C : public Protocole {
    public:
        ProtocoleI2C(const string & nom, const string & description_utilisation);
        virtual bool configure_toi(int fd, uint16_t &adresse);
        virtual bool ecris_registre(int fd, uint8_t &config);
        virtual bool lis_registre(int fd, uint8_t * data);
};

#endif //PROTOCOLEI2C