#ifndef CAPTEUR_HPP
#define CAPTEUR_HPP

#include <string>
#include "Protocole/Protocole.hpp"

using std::string;

class Capteur {
    protected:
        string nom;
        string description;
        Protocole * protocole;
    public:
        Capteur(const string & nom = "", const string & description = "", Protocole * protocole = nullptr);
        void configurer();
        virtual void display() const = 0;
};

#endif //CAPTEUR_HPP