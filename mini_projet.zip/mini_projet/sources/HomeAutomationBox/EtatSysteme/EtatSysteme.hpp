#ifndef ETATSYSTEME_HPP
#define ETATSYSTEME_HPP

class HomeAutomationBox;

class EtatSysteme {
    public:
        virtual bool fonctionne(HomeAutomationBox &box) = 0;
};

#endif // ETATSYSTEME_HPP