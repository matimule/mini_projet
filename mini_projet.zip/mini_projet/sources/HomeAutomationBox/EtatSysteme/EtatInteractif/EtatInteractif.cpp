#include <iostream>
#include <string>
#include "EtatInteractif.hpp"
#include "../../HomeAutomationBox.hpp"
#include "../../Capteur/CapteurAda7021/CapteurAda7021.hpp"

bool EtatInteractif::fonctionne(HomeAutomationBox & box) {
    std::string commande;
    do{
        std::cout << "Entrez une commande : " << std::endl;
        std::cin >> commande;
        
        if(commande == "humi"){
            std::cout << "Humidité : " << box.getCapteur7021()->lis_humidite() << std::endl;
        }else if(commande == "temp"){
            std::cout << "Température : " << box.getCapteur7021()->lis_temperature() << std::endl;
        }
    }while(commande != "stop");

    return true;
}