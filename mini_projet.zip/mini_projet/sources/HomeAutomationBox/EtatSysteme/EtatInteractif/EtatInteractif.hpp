#ifndef ETATINTERACTIF_HPP
#define ETATINTERACTIF_HPP

#include "../EtatSysteme.hpp"

class EtatInteractif : public EtatSysteme {
    public:
        virtual bool fonctionne(HomeAutomationBox & box);
};

#endif //ETATINTERACTIF_HPP