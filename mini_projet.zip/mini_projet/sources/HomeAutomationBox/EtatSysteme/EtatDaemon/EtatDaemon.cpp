#include <unistd.h>
#include "EtatDaemon.hpp"
#include "../../HomeAutomationBox.hpp"
#include "../../Capteur/CapteurAda7021/CapteurAda7021.hpp"


bool EtatDaemon::fonctionne(HomeAutomationBox & box){
    while(1){
        box.getCapteur7021()->display();
        sleep(1);
    }
}