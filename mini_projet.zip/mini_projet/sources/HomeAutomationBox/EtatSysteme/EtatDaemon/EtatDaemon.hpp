#ifndef ETATDAEMON_HPP
#define ETATDAEMON_HPP

#include "../EtatSysteme.hpp"

class EtatDaemon : public EtatSysteme {
    public:
        virtual bool fonctionne(HomeAutomationBox  & box);
};

#endif //ETATDAEMON_HPP