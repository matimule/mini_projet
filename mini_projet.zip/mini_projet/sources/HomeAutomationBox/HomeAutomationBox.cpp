#include "HomeAutomationBox.hpp"

#include "EtatSysteme/EtatSysteme.hpp"

#include "Capteur/CapteurAda7021/CapteurAda7021.hpp"



HomeAutomationBox::HomeAutomationBox(CapteurAda7021 * capteur7021, EtatSysteme * etat_systeme)
    :capteur7021(capteur7021), etat_systeme(etat_systeme){}

const CapteurAda7021 * HomeAutomationBox::getCapteur7021() const{
    return this->capteur7021;
}

void HomeAutomationBox::setEtatSysteme(EtatSysteme * etat_systeme){
    this->etat_systeme = etat_systeme;
}

bool HomeAutomationBox::lance_toi(){
    return etat_systeme->fonctionne(*this);
}