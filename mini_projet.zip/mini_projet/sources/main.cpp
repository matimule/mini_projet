#include <cstdlib>
#include "HomeAutomationBox/HomeAutomationBox.hpp"
#include "HomeAutomationBox/Capteur/Capteur.hpp"
#include "HomeAutomationBox/Capteur/CapteurAda7021/CapteurAda7021.hpp"
#include "HomeAutomationBox/EtatSysteme/EtatSysteme.hpp"
#include "HomeAutomationBox/EtatSysteme/EtatInteractif/EtatInteractif.hpp"
#include "HomeAutomationBox/EtatSysteme/EtatDaemon/EtatDaemon.hpp"
#include "HomeAutomationBox/Capteur/Protocole/Protocole.hpp"
#include "HomeAutomationBox/Capteur/Protocole/ProtocoleI2C/ProtocoleI2C.hpp"

int main(void){
    uint16_t adresse = 0x40;
    ProtocoleI2C prot("I2C", "Protocole");
    CapteurAda7021 capteur("Capteur Temp/Humi", "Pour mesurer la temperature et l'humidité", &prot, adresse);
    EtatDaemon etatD;
    EtatInteractif etatI;
    HomeAutomationBox box(&capteur, &etatI);
    box.lance_toi();
    box.setEtatSysteme(&etatD);
    box.lance_toi();
    return EXIT_SUCCESS;
}